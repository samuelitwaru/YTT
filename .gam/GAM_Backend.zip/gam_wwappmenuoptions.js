/*
               File: GAM_WWAppMenuOptions
        Description: Application menu options
             Author: GeneXus .NET Generator version 18_0_6-177934
       Generated on: 11/2/2023 1:23:0.97
       Program type: Callable routine
          Main DBMS: SQL Server
*/
gx.evt.autoSkip = false;
gx.define('gam_wwappmenuoptions', false, function () {
   this.ServerClass =  "gam_wwappmenuoptions" ;
   this.PackageName =  "GeneXus.Security.Backend" ;
   this.ServerFullClass =  "gam_wwappmenuoptions.aspx" ;
   this.setObjectType("web");
   this.setAjaxSecurity(false);
   this.setOnAjaxSessionTimeout("Warn");
   this.hasEnterEvent = false;
   this.skipOnEnter = false;
   this.fullAjax = true;
   this.supportAjaxEvents =  true ;
   this.ajaxSecurityToken =  true ;
   this.DSO =  "GAMDesignSystem" ;
   this.SetStandaloneVars=function()
   {
      this.AV6ApplicationId=gx.fn.getIntegerValue("vAPPLICATIONID",gx.thousandSeparator) ;
      this.AV19MenuId=gx.fn.getIntegerValue("vMENUID",gx.thousandSeparator) ;
      this.subGridww_Recordcount=gx.fn.getIntegerValue("subGridww_Recordcount",gx.thousandSeparator) ;
   };
   this.Validv_Type=function()
   {
      var currentRow = gx.fn.currentGridRowImpl(31);
      return this.validCliEvt("Validv_Type", 31, function () {
      try {
         var gxballoon = gx.util.balloon.getNew("vTYPE");
         this.AnyError  = 0;
         if ( ! ( gx.text.compare( this.AV25Type , "S" ) == 0 || gx.text.compare( this.AV25Type , "M" ) == 0 ) )
         {
            try {
               gxballoon.setError(gx.text.format( gx.getMessage( "GXSPC_OutOfRange"), gx.getMessage( "Type"), "", "", "", "", "", "", "", ""));
               this.AnyError = gx.num.trunc( 1 ,0) ;
            }
            catch(e){}
         }

      }
      catch(e){}
      try {
          if (gxballoon == null) return true; return gxballoon.show();
      }
      catch(e){}
      return true ;
      });
   }
   this.e182i1_client=function()
   {
      /* Search_Controlvaluechanged Routine */
      this.clearMessages();
      this.refreshOutputs([]);
      this.refreshGrid('Gridww') ;
      this.refreshOutputs([]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e112i1_client=function()
   {
      /* 'AddNew' Routine */
      this.clearMessages();
      this.call("gam_appmenuoptionentry.aspx", ["INS", this.AV6ApplicationId, this.AV19MenuId, 0], null, ["Mode","ApplicationId","MenuId","Id"]);
      this.refreshOutputs([{av:'AV19MenuId',fld:'vMENUID',pic:'ZZZZZZZZZZZ9'},{av:'AV6ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'}]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e192i1_client=function()
   {
      /* Gam_headerwwback_tableback_Click Routine */
      this.clearMessages();
      this.call("gam_wwappmenus.aspx", [this.AV6ApplicationId], null, ["ApplicationId"]);
      this.refreshOutputs([{av:'AV6ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'}]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e152i2_client=function()
   {
      /* Name_Click Routine */
      this.clearMessages();
      this.call("gam_appmenuoptionentry.aspx", ["DSP", this.AV6ApplicationId, this.AV19MenuId, this.AV17Id], null, ["Mode","ApplicationId","MenuId","Id"]);
      this.refreshOutputs([{av:'AV17Id',fld:'vID',pic:'ZZZZZZZZZZZ9'},{av:'AV19MenuId',fld:'vMENUID',pic:'ZZZZZZZZZZZ9'},{av:'AV6ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'}]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e162i2_client=function()
   {
      /* Btnupd_Click Routine */
      this.clearMessages();
      this.call("gam_appmenuoptionentry.aspx", ["UPD", this.AV6ApplicationId, this.AV19MenuId, this.AV17Id], null, ["Mode","ApplicationId","MenuId","Id"]);
      this.refreshOutputs([{av:'AV17Id',fld:'vID',pic:'ZZZZZZZZZZZ9'},{av:'AV19MenuId',fld:'vMENUID',pic:'ZZZZZZZZZZZ9'},{av:'AV6ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'}]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e172i2_client=function()
   {
      /* Btndlt_Click Routine */
      this.clearMessages();
      this.call("gam_appmenuoptionentry.aspx", ["DLT", this.AV6ApplicationId, this.AV19MenuId, this.AV17Id], null, ["Mode","ApplicationId","MenuId","Id"]);
      this.refreshOutputs([{av:'AV17Id',fld:'vID',pic:'ZZZZZZZZZZZ9'},{av:'AV19MenuId',fld:'vMENUID',pic:'ZZZZZZZZZZZ9'},{av:'AV6ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'}]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.s112_client=function()
   {
      /* 'SHOWMESSAGES' Routine */
      this.createWebComponent('Wcmessages','GAM_Messages',[]);
   };
   this.e132i2_client=function()
   {
      /* Btnup_Click Routine */
      return this.executeServerEvent("VBTNUP.CLICK", true, arguments[0], false, false);
   };
   this.e142i2_client=function()
   {
      /* Btndown_Click Routine */
      return this.executeServerEvent("VBTNDOWN.CLICK", true, arguments[0], false, false);
   };
   this.e202i2_client=function()
   {
      /* Enter Routine */
      return this.executeServerEvent("ENTER", true, arguments[0], false, false);
   };
   this.e212i2_client=function()
   {
      /* Cancel Routine */
      return this.executeServerEvent("CANCEL", true, arguments[0], false, false);
   };
   this.GXValidFnc = [];
   var GXValidFnc = this.GXValidFnc ;
   this.GXCtrlIds=[2,3,4,5,6,7,8,9,10,11,12,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,32,33,34,35,36,37,38,39,40];
   this.GXLastCtrlId =40;
   this.GridwwContainer = new gx.grid.grid(this, 2,"WbpLvl2",31,"Gridww","Gridww","GridwwContainer",this.CmpContext,this.IsMasterPage,"gam_wwappmenuoptions",[],false,1,false,true,10,true,false,false,"",0,"px",0,"px",gx.getMessage( "GXM_newrow"),true,false,false,null,null,false,"",false,[1,1,1,1],false,0,true,false);
   var GridwwContainer = this.GridwwContainer;
   GridwwContainer.addSingleLineEdit("Name",32,"vNAME",gx.getMessage( "GAM_Menuname"),"","Name","char",0,"px",120,80,"start","e152i2_client",[],"Name","Name",true,0,false,false,"Attribute",0,"column");
   GridwwContainer.addComboBox("Type",33,"vTYPE",gx.getMessage( "GAM_Type"),"Type","char",null,0,true,false,100,"px","column column-optional");
   GridwwContainer.addSingleLineEdit("Btnup",34,"vBTNUP","","","BtnUp","char",0,"px",20,20,"start","e132i2_client",[],"Btnup","BtnUp",true,0,false,false,"TextActionAttribute",0,"WWTextActionColumn column-optional");
   GridwwContainer.addSingleLineEdit("Btndown",35,"vBTNDOWN","","","BtnDown","char",0,"px",20,20,"start","e142i2_client",[],"Btndown","BtnDown",true,0,false,false,"TextActionAttribute",0,"WWTextActionColumn column-optional");
   GridwwContainer.addSingleLineEdit("Btnupd",36,"vBTNUPD","","","BtnUpd","char",0,"px",20,20,"start","e162i2_client",[],"Btnupd","BtnUpd",true,0,false,false,"TextActionAttribute",0,"WWTextActionColumn column-optional");
   GridwwContainer.addSingleLineEdit("Btndlt",37,"vBTNDLT","","","BtnDlt","char",0,"px",20,20,"start","e172i2_client",[],"Btndlt","BtnDlt",true,0,false,false,"TextActionAttribute",0,"WWTextActionColumn column-optional");
   GridwwContainer.addSingleLineEdit("Id",38,"vID",gx.getMessage( "GAM_ID"),"","Id","int",0,"px",12,12,"end",null,[],"Id","Id",false,0,false,false,"Attribute",0,"");
   this.GridwwContainer.emptyText = gx.getMessage( "No results found.");
   this.setGrid(GridwwContainer);
   GXValidFnc[2]={ id: 2, fld:"",grid:0};
   GXValidFnc[3]={ id: 3, fld:"MAINTABLE",grid:0};
   GXValidFnc[4]={ id: 4, fld:"",grid:0};
   GXValidFnc[5]={ id: 5, fld:"",grid:0};
   GXValidFnc[6]={ id: 6, fld:"GAM_HEADERWWBACK",grid:0};
   GXValidFnc[7]={ id: 7, fld:"",grid:0};
   GXValidFnc[8]={ id: 8, fld:"",grid:0};
   GXValidFnc[9]={ id: 9, fld:"GAM_HEADERWWBACK_TBLBACKCONTAINER",grid:0};
   GXValidFnc[10]={ id: 10, fld:"",grid:0};
   GXValidFnc[11]={ id: 11, fld:"",grid:0};
   GXValidFnc[12]={ id: 12, fld:"GAM_HEADERWWBACK_TABLEBACK",grid:0,evt:"e192i1_client"};
   GXValidFnc[15]={ id: 15, fld:"GAM_HEADERWWBACK_TXTBACK", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[16]={ id: 16, fld:"",grid:0};
   GXValidFnc[17]={ id: 17, fld:"",grid:0};
   GXValidFnc[18]={ id: 18, fld:"GAM_HEADERWWBACK_TABLEACTIONS",grid:0};
   GXValidFnc[19]={ id: 19, fld:"",grid:0};
   GXValidFnc[20]={ id: 20, fld:"GAM_HEADERWWBACK_TITLE", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[21]={ id: 21, fld:"",grid:0};
   GXValidFnc[22]={ id: 22, fld:"GAM_HEADERWWBACK_ADDNEW",grid:0,evt:"e112i1_client"};
   GXValidFnc[23]={ id: 23, fld:"",grid:0};
   GXValidFnc[24]={ id: 24, fld:"",grid:0};
   GXValidFnc[25]={ id:25 ,lvl:0,type:"svchar",len:100,dec:60,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:'e182i1_client',evt_cvcing:null,rgrid:[],fld:"vSEARCH",fmt:0,gxz:"ZV26Search",gxold:"OV26Search",gxvar:"AV26Search",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV26Search=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV26Search=Value},v2c:function(){gx.fn.setControlValue("vSEARCH",gx.O.AV26Search,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV26Search=this.val()},val:function(){return gx.fn.getControlValue("vSEARCH")},nac:gx.falseFn};
   this.declareDomainHdlr( 25 , function() {
   });
   GXValidFnc[26]={ id: 26, fld:"",grid:0};
   GXValidFnc[27]={ id: 27, fld:"",grid:0};
   GXValidFnc[28]={ id: 28, fld:"GRIDCONTAINER",grid:0};
   GXValidFnc[29]={ id: 29, fld:"",grid:0};
   GXValidFnc[30]={ id: 30, fld:"",grid:0};
   GXValidFnc[32]={ id:32 ,lvl:2,type:"char",len:120,dec:0,sign:false,ro:0,isacc:0,grid:31,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vNAME",fmt:0,gxz:"ZV21Name",gxold:"OV21Name",gxvar:"AV21Name",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV21Name=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV21Name=Value},v2c:function(row){gx.fn.setGridControlValue("vNAME",row || gx.fn.currentGridRowImpl(31),gx.O.AV21Name,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV21Name=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vNAME",row || gx.fn.currentGridRowImpl(31))},nac:gx.falseFn,evt:"e152i2_client"};
   GXValidFnc[33]={ id:33 ,lvl:2,type:"char",len:1,dec:0,sign:false,ro:0,isacc:0,grid:31,gxgrid:this.GridwwContainer,fnc:this.Validv_Type,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vTYPE",fmt:0,gxz:"ZV25Type",gxold:"OV25Type",gxvar:"AV25Type",ucs:[],op:[33],ip:[33],nacdep:[],ctrltype:"combo",inputType:'text',v2v:function(Value){if(Value!==undefined)gx.O.AV25Type=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV25Type=Value},v2c:function(row){gx.fn.setGridComboBoxValue("vTYPE",row || gx.fn.currentGridRowImpl(31),gx.O.AV25Type);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV25Type=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vTYPE",row || gx.fn.currentGridRowImpl(31))},nac:gx.falseFn};
   GXValidFnc[34]={ id:34 ,lvl:2,type:"char",len:20,dec:0,sign:false,ro:0,isacc:0,grid:31,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vBTNUP",fmt:0,gxz:"ZV10BtnUp",gxold:"OV10BtnUp",gxvar:"AV10BtnUp",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV10BtnUp=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV10BtnUp=Value},v2c:function(row){gx.fn.setGridControlValue("vBTNUP",row || gx.fn.currentGridRowImpl(31),gx.O.AV10BtnUp,0)},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV10BtnUp=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vBTNUP",row || gx.fn.currentGridRowImpl(31))},nac:gx.falseFn,evt:"e132i2_client"};
   GXValidFnc[35]={ id:35 ,lvl:2,type:"char",len:20,dec:0,sign:false,ro:0,isacc:0,grid:31,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vBTNDOWN",fmt:0,gxz:"ZV9BtnDown",gxold:"OV9BtnDown",gxvar:"AV9BtnDown",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV9BtnDown=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV9BtnDown=Value},v2c:function(row){gx.fn.setGridControlValue("vBTNDOWN",row || gx.fn.currentGridRowImpl(31),gx.O.AV9BtnDown,0)},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV9BtnDown=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vBTNDOWN",row || gx.fn.currentGridRowImpl(31))},nac:gx.falseFn,evt:"e142i2_client"};
   GXValidFnc[36]={ id:36 ,lvl:2,type:"char",len:20,dec:0,sign:false,ro:0,isacc:0,grid:31,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vBTNUPD",fmt:0,gxz:"ZV11BtnUpd",gxold:"OV11BtnUpd",gxvar:"AV11BtnUpd",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV11BtnUpd=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV11BtnUpd=Value},v2c:function(row){gx.fn.setGridControlValue("vBTNUPD",row || gx.fn.currentGridRowImpl(31),gx.O.AV11BtnUpd,0)},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV11BtnUpd=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vBTNUPD",row || gx.fn.currentGridRowImpl(31))},nac:gx.falseFn,evt:"e162i2_client"};
   GXValidFnc[37]={ id:37 ,lvl:2,type:"char",len:20,dec:0,sign:false,ro:0,isacc:0,grid:31,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vBTNDLT",fmt:0,gxz:"ZV8BtnDlt",gxold:"OV8BtnDlt",gxvar:"AV8BtnDlt",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV8BtnDlt=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV8BtnDlt=Value},v2c:function(row){gx.fn.setGridControlValue("vBTNDLT",row || gx.fn.currentGridRowImpl(31),gx.O.AV8BtnDlt,0)},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV8BtnDlt=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vBTNDLT",row || gx.fn.currentGridRowImpl(31))},nac:gx.falseFn,evt:"e172i2_client"};
   GXValidFnc[38]={ id:38 ,lvl:2,type:"int",len:12,dec:0,sign:false,pic:"ZZZZZZZZZZZ9",ro:0,isacc:0,grid:31,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vID",fmt:0,gxz:"ZV17Id",gxold:"OV17Id",gxvar:"AV17Id",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',v2v:function(Value){if(Value!==undefined)gx.O.AV17Id=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV17Id=gx.num.intval(Value)},v2c:function(row){gx.fn.setGridControlValue("vID",row || gx.fn.currentGridRowImpl(31),gx.O.AV17Id,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV17Id=gx.num.intval(this.val(row))},val:function(row){return gx.fn.getGridIntegerValue("vID",row || gx.fn.currentGridRowImpl(31),gx.thousandSeparator)},nac:gx.falseFn};
   GXValidFnc[39]={ id: 39, fld:"",grid:0};
   GXValidFnc[40]={ id: 40, fld:"",grid:0};
   this.AV26Search = "" ;
   this.ZV26Search = "" ;
   this.OV26Search = "" ;
   this.ZV21Name = "" ;
   this.OV21Name = "" ;
   this.ZV25Type = "" ;
   this.OV25Type = "" ;
   this.ZV10BtnUp = "" ;
   this.OV10BtnUp = "" ;
   this.ZV9BtnDown = "" ;
   this.OV9BtnDown = "" ;
   this.ZV11BtnUpd = "" ;
   this.OV11BtnUpd = "" ;
   this.ZV8BtnDlt = "" ;
   this.OV8BtnDlt = "" ;
   this.ZV17Id = 0 ;
   this.OV17Id = 0 ;
   this.AV26Search = "" ;
   this.AV6ApplicationId = 0 ;
   this.AV19MenuId = 0 ;
   this.AV21Name = "" ;
   this.AV25Type = "" ;
   this.AV10BtnUp = "" ;
   this.AV9BtnDown = "" ;
   this.AV11BtnUpd = "" ;
   this.AV8BtnDlt = "" ;
   this.AV17Id = 0 ;
   this.Events = {"e132i2_client": ["VBTNUP.CLICK", true] ,"e142i2_client": ["VBTNDOWN.CLICK", true] ,"e202i2_client": ["ENTER", true] ,"e212i2_client": ["CANCEL", true] ,"e182i1_client": ["VSEARCH.CONTROLVALUECHANGED", false] ,"e112i1_client": ["'ADDNEW'", false] ,"e192i1_client": ["GAM_HEADERWWBACK_TABLEBACK.CLICK", false] ,"e152i2_client": ["VNAME.CLICK", false] ,"e162i2_client": ["VBTNUPD.CLICK", false] ,"e172i2_client": ["VBTNDLT.CLICK", false]};
   this.EvtParms["REFRESH"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{ctrl:'GRIDWW',prop:'Rows'},{av:'AV6ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'},{av:'AV19MenuId',fld:'vMENUID',pic:'ZZZZZZZZZZZ9'},{av:'AV26Search',fld:'vSEARCH',pic:''}],[]];
   this.EvtParms["GRIDWW.LOAD"] = [[{av:'AV6ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'},{av:'AV19MenuId',fld:'vMENUID',pic:'ZZZZZZZZZZZ9'},{av:'AV26Search',fld:'vSEARCH',pic:''}],[{av:'gx.fn.getCtrlProperty("GAM_HEADERWWBACK_TITLE","Caption")',ctrl:'GAM_HEADERWWBACK_TITLE',prop:'Caption'},{av:'AV11BtnUpd',fld:'vBTNUPD',pic:''},{av:'AV8BtnDlt',fld:'vBTNDLT',pic:''},{av:'AV10BtnUp',fld:'vBTNUP',pic:''},{av:'AV9BtnDown',fld:'vBTNDOWN',pic:''},{av:'AV17Id',fld:'vID',pic:'ZZZZZZZZZZZ9'},{av:'AV21Name',fld:'vNAME',pic:''},{ctrl:'vTYPE'},{av:'AV25Type',fld:'vTYPE',pic:''}]];
   this.EvtParms["VSEARCH.CONTROLVALUECHANGED"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{ctrl:'GRIDWW',prop:'Rows'},{av:'AV6ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'},{av:'AV19MenuId',fld:'vMENUID',pic:'ZZZZZZZZZZZ9'},{av:'AV26Search',fld:'vSEARCH',pic:''}],[]];
   this.EvtParms["'ADDNEW'"] = [[{av:'AV6ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'},{av:'AV19MenuId',fld:'vMENUID',pic:'ZZZZZZZZZZZ9'}],[{av:'AV19MenuId',fld:'vMENUID',pic:'ZZZZZZZZZZZ9'},{av:'AV6ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'}]];
   this.EvtParms["GAM_HEADERWWBACK_TABLEBACK.CLICK"] = [[{av:'AV6ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'}],[{av:'AV6ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'}]];
   this.EvtParms["VNAME.CLICK"] = [[{av:'AV6ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'},{av:'AV19MenuId',fld:'vMENUID',pic:'ZZZZZZZZZZZ9'},{av:'AV17Id',fld:'vID',pic:'ZZZZZZZZZZZ9'}],[{av:'AV17Id',fld:'vID',pic:'ZZZZZZZZZZZ9'},{av:'AV19MenuId',fld:'vMENUID',pic:'ZZZZZZZZZZZ9'},{av:'AV6ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'}]];
   this.EvtParms["VBTNUPD.CLICK"] = [[{av:'AV6ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'},{av:'AV19MenuId',fld:'vMENUID',pic:'ZZZZZZZZZZZ9'},{av:'AV17Id',fld:'vID',pic:'ZZZZZZZZZZZ9'}],[{av:'AV17Id',fld:'vID',pic:'ZZZZZZZZZZZ9'},{av:'AV19MenuId',fld:'vMENUID',pic:'ZZZZZZZZZZZ9'},{av:'AV6ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'}]];
   this.EvtParms["VBTNDLT.CLICK"] = [[{av:'AV6ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'},{av:'AV19MenuId',fld:'vMENUID',pic:'ZZZZZZZZZZZ9'},{av:'AV17Id',fld:'vID',pic:'ZZZZZZZZZZZ9'}],[{av:'AV17Id',fld:'vID',pic:'ZZZZZZZZZZZ9'},{av:'AV19MenuId',fld:'vMENUID',pic:'ZZZZZZZZZZZ9'},{av:'AV6ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'}]];
   this.EvtParms["VBTNUP.CLICK"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{ctrl:'GRIDWW',prop:'Rows'},{av:'AV6ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'},{av:'AV19MenuId',fld:'vMENUID',pic:'ZZZZZZZZZZZ9'},{av:'AV26Search',fld:'vSEARCH',pic:''},{av:'AV17Id',fld:'vID',pic:'ZZZZZZZZZZZ9'}],[{ctrl:'WCMESSAGES'}]];
   this.EvtParms["VBTNDOWN.CLICK"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{ctrl:'GRIDWW',prop:'Rows'},{av:'AV6ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'},{av:'AV19MenuId',fld:'vMENUID',pic:'ZZZZZZZZZZZ9'},{av:'AV26Search',fld:'vSEARCH',pic:''},{av:'AV17Id',fld:'vID',pic:'ZZZZZZZZZZZ9'}],[{ctrl:'WCMESSAGES'}]];
   this.EvtParms["ENTER"] = [[],[]];
   this.EvtParms["GRIDWW_FIRSTPAGE"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{ctrl:'GRIDWW',prop:'Rows'},{av:'AV6ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'},{av:'AV19MenuId',fld:'vMENUID',pic:'ZZZZZZZZZZZ9'},{av:'AV26Search',fld:'vSEARCH',pic:''}],[]];
   this.EvtParms["GRIDWW_PREVPAGE"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{ctrl:'GRIDWW',prop:'Rows'},{av:'AV6ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'},{av:'AV19MenuId',fld:'vMENUID',pic:'ZZZZZZZZZZZ9'},{av:'AV26Search',fld:'vSEARCH',pic:''}],[]];
   this.EvtParms["GRIDWW_NEXTPAGE"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{ctrl:'GRIDWW',prop:'Rows'},{av:'AV6ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'},{av:'AV19MenuId',fld:'vMENUID',pic:'ZZZZZZZZZZZ9'},{av:'AV26Search',fld:'vSEARCH',pic:''}],[]];
   this.EvtParms["GRIDWW_LASTPAGE"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{ctrl:'GRIDWW',prop:'Rows'},{av:'AV6ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'},{av:'AV19MenuId',fld:'vMENUID',pic:'ZZZZZZZZZZZ9'},{av:'AV26Search',fld:'vSEARCH',pic:''},{av:'subGridww_Recordcount'}],[]];
   this.EvtParms["VALIDV_TYPE"] = [[{ctrl:'vTYPE'},{av:'AV25Type',fld:'vTYPE',pic:''}],[{ctrl:'vTYPE'},{av:'AV25Type',fld:'vTYPE',pic:''}]];
   this.setVCMap("AV6ApplicationId", "vAPPLICATIONID", 0, "int", 12, 0);
   this.setVCMap("AV19MenuId", "vMENUID", 0, "int", 12, 0);
   this.setVCMap("AV6ApplicationId", "vAPPLICATIONID", 0, "int", 12, 0);
   this.setVCMap("AV19MenuId", "vMENUID", 0, "int", 12, 0);
   this.setVCMap("AV6ApplicationId", "vAPPLICATIONID", 0, "int", 12, 0);
   this.setVCMap("AV19MenuId", "vMENUID", 0, "int", 12, 0);
   this.setVCMap("AV6ApplicationId", "vAPPLICATIONID", 0, "int", 12, 0);
   this.setVCMap("AV19MenuId", "vMENUID", 0, "int", 12, 0);
   GridwwContainer.addRefreshingParm({rfrProp:"Rows", gxGrid:"Gridww"});
   GridwwContainer.addRefreshingVar({rfrVar:"AV6ApplicationId"});
   GridwwContainer.addRefreshingVar({rfrVar:"AV19MenuId"});
   GridwwContainer.addRefreshingVar(this.GXValidFnc[25]);
   GridwwContainer.addRefreshingParm({rfrVar:"AV6ApplicationId"});
   GridwwContainer.addRefreshingParm({rfrVar:"AV19MenuId"});
   GridwwContainer.addRefreshingParm(this.GXValidFnc[25]);
   this.Initialize( );
   this.setComponent({id: "WCMESSAGES" ,GXClass: null , Prefix: "W0041" , lvl: 1 });
});
gx.wi( function() { gx.createParentObj(this.gam_wwappmenuoptions);});
