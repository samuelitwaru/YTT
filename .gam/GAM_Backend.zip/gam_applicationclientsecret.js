/*
               File: GAM_ApplicationClientSecret
        Description: GAM_Application Client Secret
             Author: GeneXus .NET Generator version 18_0_6-177934
       Generated on: 11/2/2023 1:23:48.46
       Program type: Callable routine
          Main DBMS: SQL Server
*/
gx.evt.autoSkip = false;
gx.define('gam_applicationclientsecret', false, function () {
   this.ServerClass =  "gam_applicationclientsecret" ;
   this.PackageName =  "GeneXus.Security.Backend" ;
   this.ServerFullClass =  "gam_applicationclientsecret.aspx" ;
   this.setObjectType("web");
   this.setAjaxSecurity(false);
   this.setOnAjaxSessionTimeout("Warn");
   this.hasEnterEvent = false;
   this.skipOnEnter = false;
   this.autoRefresh = true;
   this.fullAjax = true;
   this.supportAjaxEvents =  true ;
   this.ajaxSecurityToken =  true ;
   this.DSO =  "GAMDesignSystem" ;
   this.SetStandaloneVars=function()
   {
   };
   this.s112_client=function()
   {
      /* 'SHOWMESSAGES' Routine */
      this.createWebComponent('Wcmessages','GAM_Messages',[]);
   };
   this.e123d2_client=function()
   {
      /* 'Autogenerate' Routine */
      return this.executeServerEvent("'AUTOGENERATE'", false, null, false, false);
   };
   this.e133d2_client=function()
   {
      /* 'Confirm' Routine */
      return this.executeServerEvent("'CONFIRM'", false, null, false, false);
   };
   this.e153d2_client=function()
   {
      /* Enter Routine */
      return this.executeServerEvent("ENTER", true, null, false, false);
   };
   this.e163d2_client=function()
   {
      /* Cancel Routine */
      return this.executeServerEvent("CANCEL", true, null, false, false);
   };
   this.GXValidFnc = [];
   var GXValidFnc = this.GXValidFnc ;
   this.GXCtrlIds=[2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,21,22,23,24,25,26,27,28,29,30];
   this.GXLastCtrlId =30;
   GXValidFnc[2]={ id: 2, fld:"",grid:0};
   GXValidFnc[3]={ id: 3, fld:"MAINTABLE",grid:0};
   GXValidFnc[4]={ id: 4, fld:"",grid:0};
   GXValidFnc[5]={ id: 5, fld:"",grid:0};
   GXValidFnc[6]={ id: 6, fld:"",grid:0};
   GXValidFnc[7]={ id: 7, fld:"",grid:0};
   GXValidFnc[8]={ id:8 ,lvl:0,type:"char",len:40,dec:0,sign:false,ro:1,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCLIENTID",fmt:0,gxz:"ZV5ClientID",gxold:"OV5ClientID",gxvar:"AV5ClientID",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV5ClientID=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV5ClientID=Value},v2c:function(){gx.fn.setControlValue("vCLIENTID",gx.O.AV5ClientID,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV5ClientID=this.val()},val:function(){return gx.fn.getControlValue("vCLIENTID")},nac:gx.falseFn};
   this.declareDomainHdlr( 8 , function() {
   });
   GXValidFnc[9]={ id: 9, fld:"",grid:0};
   GXValidFnc[10]={ id: 10, fld:"",grid:0};
   GXValidFnc[11]={ id: 11, fld:"",grid:0};
   GXValidFnc[12]={ id: 12, fld:"",grid:0};
   GXValidFnc[13]={ id: 13, fld:"",grid:0};
   GXValidFnc[14]={ id:14 ,lvl:0,type:"char",len:120,dec:0,sign:false,isPwd:true,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCLIENTSECRET",fmt:0,gxz:"ZV6ClientSecret",gxold:"OV6ClientSecret",gxvar:"AV6ClientSecret",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV6ClientSecret=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV6ClientSecret=Value},v2c:function(){gx.fn.setControlValue("vCLIENTSECRET",gx.O.AV6ClientSecret,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV6ClientSecret=this.val()},val:function(){return gx.fn.getControlValue("vCLIENTSECRET")},nac:gx.falseFn};
   this.declareDomainHdlr( 14 , function() {
   });
   GXValidFnc[15]={ id: 15, fld:"",grid:0};
   GXValidFnc[16]={ id: 16, fld:"BTNAUTOGENERATE",grid:0,evt:"e123d2_client"};
   GXValidFnc[17]={ id: 17, fld:"",grid:0};
   GXValidFnc[18]={ id: 18, fld:"",grid:0};
   GXValidFnc[19]={ id: 19, fld:"",grid:0};
   GXValidFnc[21]={ id: 21, fld:"",grid:0};
   GXValidFnc[22]={ id: 22, fld:"",grid:0};
   GXValidFnc[23]={ id: 23, fld:"GAM_FOOTERPOPUP",grid:0};
   GXValidFnc[24]={ id: 24, fld:"",grid:0};
   GXValidFnc[25]={ id: 25, fld:"",grid:0};
   GXValidFnc[26]={ id: 26, fld:"GAM_FOOTERPOPUP_TABLEBUTTONS",grid:0};
   GXValidFnc[27]={ id: 27, fld:"",grid:0};
   GXValidFnc[28]={ id: 28, fld:"GAM_FOOTERPOPUP_BTNCANCEL",grid:0,evt:"e173d1_client"};
   GXValidFnc[29]={ id: 29, fld:"",grid:0};
   GXValidFnc[30]={ id: 30, fld:"GAM_FOOTERPOPUP_BTNCONFIRM",grid:0,evt:"e133d2_client"};
   this.AV5ClientID = "" ;
   this.ZV5ClientID = "" ;
   this.OV5ClientID = "" ;
   this.AV6ClientSecret = "" ;
   this.ZV6ClientSecret = "" ;
   this.OV6ClientSecret = "" ;
   this.AV5ClientID = "" ;
   this.AV6ClientSecret = "" ;
   this.Events = {"e123d2_client": ["'AUTOGENERATE'", true] ,"e133d2_client": ["'CONFIRM'", true] ,"e153d2_client": ["ENTER", true] ,"e163d2_client": ["CANCEL", true]};
   this.EvtParms["REFRESH"] = [[{av:'AV5ClientID',fld:'vCLIENTID',pic:'',hsh:true}],[]];
   this.EvtParms["'AUTOGENERATE'"] = [[],[{av:'AV6ClientSecret',fld:'vCLIENTSECRET',pic:''}]];
   this.EvtParms["'CONFIRM'"] = [[{av:'AV5ClientID',fld:'vCLIENTID',pic:'',hsh:true},{av:'AV6ClientSecret',fld:'vCLIENTSECRET',pic:''}],[{av:'gx.fn.getCtrlProperty("vCLIENTSECRET","Enabled")',ctrl:'vCLIENTSECRET',prop:'Enabled'},{ctrl:'BTNAUTOGENERATE',prop:'Visible'},{ctrl:'GAM_FOOTERPOPUP_BTNCONFIRM',prop:'Visible'},{ctrl:'WCMESSAGES'}]];
   this.EvtParms["ENTER"] = [[],[]];
   this.Initialize( );
   this.setComponent({id: "WCMESSAGES" ,GXClass: null , Prefix: "W0020" , lvl: 1 });
});
gx.wi( function() { gx.createParentObj(this.gam_applicationclientsecret);});
