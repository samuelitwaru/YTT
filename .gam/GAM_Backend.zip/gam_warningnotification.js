/*
               File: GAM_WarningNotification
        Description:
             Author: GeneXus .NET Generator version 18_0_6-177934
       Generated on: 11/2/2023 1:23:42.24
       Program type: Callable routine
          Main DBMS: SQL Server
*/
gx.evt.autoSkip = false;
gx.define('gam_warningnotification', false, function () {
   this.ServerClass =  "gam_warningnotification" ;
   this.PackageName =  "GeneXus.Security.Backend" ;
   this.ServerFullClass =  "gam_warningnotification.aspx" ;
   this.setObjectType("web");
   this.setAjaxSecurity(false);
   this.setOnAjaxSessionTimeout("Warn");
   this.hasEnterEvent = true;
   this.skipOnEnter = false;
   this.autoRefresh = true;
   this.fullAjax = true;
   this.supportAjaxEvents =  true ;
   this.ajaxSecurityToken =  true ;
   this.DSO =  "GAMDesignSystem" ;
   this.SetStandaloneVars=function()
   {
      this.AV6PanelId=gx.fn.getControlValue("vPANELID") ;
      this.AV8UserGUID=gx.fn.getControlValue("vUSERGUID") ;
      this.AV10SecondaryID=gx.fn.getControlValue("vSECONDARYID") ;
   };
   this.e12362_client=function()
   {
      /* Enter Routine */
      return this.executeServerEvent("ENTER", true, null, false, false);
   };
   this.e14361_client=function()
   {
      /* Cancel Routine */
      return this.executeServerEvent("CANCEL", true, null, false, false);
   };
   this.GXValidFnc = [];
   var GXValidFnc = this.GXValidFnc ;
   this.GXCtrlIds=[2,3,4,5,6,7,8,10,11,12,13,14,15,16,17,18,19];
   this.GXLastCtrlId =19;
   this.MESSAGESContainer = gx.uc.getNew(this, 9, 0, "GeneXusUnanimo_Alert", "MESSAGESContainer", "Messages", "MESSAGES");
   var MESSAGESContainer = this.MESSAGESContainer;
   MESSAGESContainer.setProp("Class", "Class", "", "char");
   MESSAGESContainer.setProp("Enabled", "Enabled", true, "boolean");
   MESSAGESContainer.setProp("id", "Id", "1", "str");
   MESSAGESContainer.setDynProp("Type", "Type", "info", "str");
   MESSAGESContainer.setDynProp("Title", "Title", "", "str");
   MESSAGESContainer.setDynProp("Message", "Message", "", "str");
   MESSAGESContainer.setProp("Position", "Position", "Fixed to bottom", "str");
   MESSAGESContainer.setDynProp("ShowMultiple", "Showmultiple", false, "bool");
   MESSAGESContainer.setDynProp("Count", "Count", 0, "num");
   MESSAGESContainer.setDynProp("Visible", "Visible", true, "bool");
   MESSAGESContainer.setC2ShowFunction(function(UC) { UC.show(); });
   this.setUserControl(MESSAGESContainer);
   GXValidFnc[2]={ id: 2, fld:"",grid:0};
   GXValidFnc[3]={ id: 3, fld:"MAINTABLE",grid:0};
   GXValidFnc[4]={ id: 4, fld:"",grid:0};
   GXValidFnc[5]={ id: 5, fld:"",grid:0};
   GXValidFnc[6]={ id: 6, fld:"TXTMESSAGE", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[7]={ id: 7, fld:"",grid:0};
   GXValidFnc[8]={ id: 8, fld:"",grid:0};
   GXValidFnc[10]={ id: 10, fld:"",grid:0};
   GXValidFnc[11]={ id: 11, fld:"",grid:0};
   GXValidFnc[12]={ id: 12, fld:"GAM_FOOTERENTRY",grid:0};
   GXValidFnc[13]={ id: 13, fld:"",grid:0};
   GXValidFnc[14]={ id: 14, fld:"",grid:0};
   GXValidFnc[15]={ id: 15, fld:"GAM_FOOTERENTRY_TABLEBUTTONS",grid:0};
   GXValidFnc[16]={ id: 16, fld:"",grid:0};
   GXValidFnc[17]={ id: 17, fld:"GAM_FOOTERENTRY_BTNCANCEL",grid:0,evt:"e14361_client"};
   GXValidFnc[18]={ id: 18, fld:"",grid:0};
   GXValidFnc[19]={ id: 19, fld:"GAM_FOOTERENTRY_BTNCONFIRM",grid:0,evt:"e12362_client",std:"ENTER"};
   this.AV6PanelId = "" ;
   this.AV8UserGUID = "" ;
   this.AV10SecondaryID = "" ;
   this.Events = {"e12362_client": ["ENTER", true] ,"e14361_client": ["CANCEL", true]};
   this.EvtParms["REFRESH"] = [[{av:'AV6PanelId',fld:'vPANELID',pic:'',hsh:true},{av:'AV8UserGUID',fld:'vUSERGUID',pic:'',hsh:true},{av:'AV10SecondaryID',fld:'vSECONDARYID',pic:'',hsh:true}],[]];
   this.EvtParms["ENTER"] = [[{av:'AV6PanelId',fld:'vPANELID',pic:'',hsh:true},{av:'AV8UserGUID',fld:'vUSERGUID',pic:'',hsh:true},{av:'AV10SecondaryID',fld:'vSECONDARYID',pic:'',hsh:true}],[{av:'this.MESSAGESContainer.Visible',ctrl:'MESSAGES',prop:'Visible'},{av:'this.MESSAGESContainer.ShowMultiple',ctrl:'MESSAGES',prop:'ShowMultiple'},{av:'this.MESSAGESContainer.Count',ctrl:'MESSAGES',prop:'Count'},{av:'this.MESSAGESContainer.Type',ctrl:'MESSAGES',prop:'Type'},{av:'this.MESSAGESContainer.Title',ctrl:'MESSAGES',prop:'Title'},{av:'this.MESSAGESContainer.Message',ctrl:'MESSAGES',prop:'Message'}]];
   this.EnterCtrl = ["GAM_FOOTERENTRY_BTNCONFIRM"];
   this.setVCMap("AV6PanelId", "vPANELID", 0, "svchar", 40, 0);
   this.setVCMap("AV8UserGUID", "vUSERGUID", 0, "char", 40, 0);
   this.setVCMap("AV10SecondaryID", "vSECONDARYID", 0, "svchar", 40, 0);
   this.Initialize( );
});
gx.wi( function() { gx.createParentObj(this.gam_warningnotification);});
