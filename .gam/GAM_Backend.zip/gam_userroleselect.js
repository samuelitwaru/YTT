/*
               File: GAM_UserRoleSelect
        Description: Select user roles
             Author: GeneXus .NET Generator version 18_0_6-177934
       Generated on: 11/2/2023 1:22:37.3
       Program type: Callable routine
          Main DBMS: SQL Server
*/
gx.evt.autoSkip = false;
gx.define('gam_userroleselect', false, function () {
   this.ServerClass =  "gam_userroleselect" ;
   this.PackageName =  "GeneXus.Security.Backend" ;
   this.ServerFullClass =  "gam_userroleselect.aspx" ;
   this.setObjectType("web");
   this.setAjaxSecurity(false);
   this.setOnAjaxSessionTimeout("Warn");
   this.hasEnterEvent = false;
   this.skipOnEnter = false;
   this.autoRefresh = true;
   this.fullAjax = true;
   this.supportAjaxEvents =  true ;
   this.ajaxSecurityToken =  true ;
   this.DSO =  "GAMDesignSystem" ;
   this.SetStandaloneVars=function()
   {
      this.AV29UserGUID=gx.fn.getControlValue("vUSERGUID") ;
      this.AV17isOK=gx.fn.getControlValue("vISOK") ;
      this.subGridww_Recordcount=gx.fn.getIntegerValue("subGridww_Recordcount",gx.thousandSeparator) ;
   };
   this.s112_client=function()
   {
      /* 'SHOWMESSAGES' Routine */
      this.createWebComponent('Wcmessages','GAM_Messages',[]);
   };
   this.e132f1_client=function()
   {
      /* 'Apply' Routine */
      this.clearMessages();
      this.refreshOutputs([]);
      this.refreshGrid('Gridww') ;
      this.refreshOutputs([]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e122f1_client=function()
   {
      /* 'ClearFilters' Routine */
      this.clearMessages();
      this.AV30FilRoleGUID =  ''  ;
      this.AV11FilExternalId =  ''  ;
      this.refreshOutputs([{av:'AV30FilRoleGUID',fld:'vFILROLEGUID',pic:''},{av:'AV11FilExternalId',fld:'vFILEXTERNALID',pic:''}]);
      this.refreshGrid('Gridww') ;
      this.refreshOutputs([{av:'AV30FilRoleGUID',fld:'vFILROLEGUID',pic:''},{av:'AV11FilExternalId',fld:'vFILEXTERNALID',pic:''}]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e112f1_client=function()
   {
      /* 'Hide' Routine */
      this.clearMessages();
      if ( gx.text.compare( gx.fn.getCtrlProperty("GAM_FILTERSWW","Class") , "filters-container" ) == 0 )
      {
         gx.fn.setCtrlProperty("GAM_FILTERSWW","Class", gx.text.format( "%1 %2", "filters-container", "filters-container-floating--visible", "", "", "", "", "", "", "") );
         gx.fn.setCtrlProperty("GAM_HEADERWW_TOGGLEFILTERS","Tooltiptext", gx.getMessage( "GAM_Hidefilters") );
      }
      else
      {
         gx.fn.setCtrlProperty("GAM_FILTERSWW","Class", "filters-container" );
         gx.fn.setCtrlProperty("GAM_HEADERWW_TOGGLEFILTERS","Tooltiptext", gx.getMessage( "GAM_Showfilters") );
      }
      this.refreshOutputs([{av:'gx.fn.getCtrlProperty("GAM_FILTERSWW","Class")',ctrl:'GAM_FILTERSWW',prop:'Class'},{av:'gx.fn.getCtrlProperty("GAM_HEADERWW_TOGGLEFILTERS","Tooltiptext")',ctrl:'GAM_HEADERWW_TOGGLEFILTERS',prop:'Tooltiptext'}]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e182f1_client=function()
   {
      /* 'First' Routine */
      this.clearMessages();
      this.AV7CurrentPage = gx.num.trunc( 1 ,0) ;
      this.refreshOutputs([{av:'AV7CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'}]);
      this.refreshGrid('Gridww') ;
      this.refreshOutputs([{av:'AV7CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'}]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e192f1_client=function()
   {
      /* 'Previous' Routine */
      this.clearMessages();
      this.AV7CurrentPage = gx.num.trunc( this.AV7CurrentPage - 1 ,0) ;
      this.refreshOutputs([{av:'AV7CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'}]);
      this.refreshGrid('Gridww') ;
      this.refreshOutputs([{av:'AV7CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'}]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e202f1_client=function()
   {
      /* 'Next' Routine */
      this.clearMessages();
      this.AV7CurrentPage = gx.num.trunc( this.AV7CurrentPage + 1 ,0) ;
      this.refreshOutputs([{av:'AV7CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'}]);
      this.refreshGrid('Gridww') ;
      this.refreshOutputs([{av:'AV7CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'}]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e142f2_client=function()
   {
      /* 'Confirm' Routine */
      return this.executeServerEvent("'CONFIRM'", false, null, false, false);
   };
   this.e152f2_client=function()
   {
      /* 'Cancel' Routine */
      return this.executeServerEvent("'CANCEL'", false, null, false, false);
   };
   this.e212f2_client=function()
   {
      /* Enter Routine */
      return this.executeServerEvent("ENTER", true, arguments[0], false, false);
   };
   this.e222f2_client=function()
   {
      /* Cancel Routine */
      return this.executeServerEvent("CANCEL", true, arguments[0], false, false);
   };
   this.GXValidFnc = [];
   var GXValidFnc = this.GXValidFnc ;
   this.GXCtrlIds=[2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,26,27,28,29,30,31,32,33,34,37,39,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,71,72,73,74,75,76,77,78,79,80];
   this.GXLastCtrlId =80;
   this.GridwwContainer = new gx.grid.grid(this, 2,"WbpLvl2",25,"Gridww","Gridww","GridwwContainer",this.CmpContext,this.IsMasterPage,"gam_userroleselect",[],false,1,false,true,0,false,false,false,"",0,"px",0,"px",gx.getMessage( "GXM_newrow"),false,false,true,null,null,false,"",false,[1,1,1,1],false,0,true,false);
   var GridwwContainer = this.GridwwContainer;
   GridwwContainer.addCheckBox("Select",26,"vSELECT",gx.getMessage( "GAM_Select"),"","Select","boolean","true","false",null,true,false,60,"px","column");
   GridwwContainer.addSingleLineEdit("Name",27,"vNAME",gx.getMessage( "GAM_Role"),"","Name","char",0,"px",254,80,"start",null,[],"Name","Name",true,0,false,false,"Attribute",0,"column");
   GridwwContainer.addSingleLineEdit("Id",28,"vID",gx.getMessage( "GAM_KeyNumericLong"),"","Id","int",0,"px",12,12,"end",null,[],"Id","Id",false,0,false,false,"Attribute",0,"");
   this.GridwwContainer.emptyText = gx.getMessage( "No results found.");
   this.setGrid(GridwwContainer);
   GXValidFnc[2]={ id: 2, fld:"",grid:0};
   GXValidFnc[3]={ id: 3, fld:"MAINTABLE",grid:0};
   GXValidFnc[4]={ id: 4, fld:"",grid:0};
   GXValidFnc[5]={ id: 5, fld:"",grid:0};
   GXValidFnc[6]={ id: 6, fld:"GAM_HEADERWW",grid:0};
   GXValidFnc[7]={ id: 7, fld:"",grid:0};
   GXValidFnc[8]={ id: 8, fld:"",grid:0};
   GXValidFnc[9]={ id: 9, fld:"GAM_HEADERWW_TABLEACTIONS",grid:0};
   GXValidFnc[10]={ id: 10, fld:"",grid:0};
   GXValidFnc[11]={ id: 11, fld:"GAM_HEADERWW_TITLE", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[12]={ id: 12, fld:"",grid:0};
   GXValidFnc[13]={ id: 13, fld:"GAM_HEADERWW_ADDNEW",grid:0,evt:"e232f1_client"};
   GXValidFnc[14]={ id: 14, fld:"CELLSEARCH",grid:0};
   GXValidFnc[15]={ id: 15, fld:"",grid:0};
   GXValidFnc[16]={ id:16 ,lvl:0,type:"svchar",len:100,dec:60,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vSEARCH",fmt:0,gxz:"ZV28Search",gxold:"OV28Search",gxvar:"AV28Search",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV28Search=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV28Search=Value},v2c:function(){gx.fn.setControlValue("vSEARCH",gx.O.AV28Search,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV28Search=this.val()},val:function(){return gx.fn.getControlValue("vSEARCH")},nac:gx.falseFn};
   this.declareDomainHdlr( 16 , function() {
   });
   GXValidFnc[17]={ id: 17, fld:"",grid:0};
   GXValidFnc[18]={ id: 18, fld:"GAM_HEADERWW_TOGGLEFILTERS",grid:0,evt:"e112f1_client"};
   GXValidFnc[19]={ id: 19, fld:"",grid:0};
   GXValidFnc[20]={ id: 20, fld:"",grid:0};
   GXValidFnc[21]={ id: 21, fld:"SECTIONGRID",grid:0};
   GXValidFnc[22]={ id: 22, fld:"GRIDTABLE",grid:0};
   GXValidFnc[23]={ id: 23, fld:"",grid:0};
   GXValidFnc[24]={ id: 24, fld:"",grid:0};
   GXValidFnc[26]={ id:26 ,lvl:2,type:"boolean",len:4,dec:0,sign:false,ro:0,isacc:0,grid:25,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vSELECT",fmt:0,gxz:"ZV22Select",gxold:"OV22Select",gxvar:"AV22Select",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"checkbox",inputType:'text',v2v:function(Value){if(Value!==undefined)gx.O.AV22Select=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV22Select=gx.lang.booleanValue(Value)},v2c:function(row){gx.fn.setGridCheckBoxValue("vSELECT",row || gx.fn.currentGridRowImpl(25),gx.O.AV22Select,true)},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV22Select=gx.lang.booleanValue(this.val(row))},val:function(row){return gx.fn.getGridControlValue("vSELECT",row || gx.fn.currentGridRowImpl(25))},nac:gx.falseFn,values:['true','false']};
   GXValidFnc[27]={ id:27 ,lvl:2,type:"char",len:254,dec:0,sign:false,ro:0,isacc:0,grid:25,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vNAME",fmt:0,gxz:"ZV18Name",gxold:"OV18Name",gxvar:"AV18Name",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV18Name=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV18Name=Value},v2c:function(row){gx.fn.setGridControlValue("vNAME",row || gx.fn.currentGridRowImpl(25),gx.O.AV18Name,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV18Name=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vNAME",row || gx.fn.currentGridRowImpl(25))},nac:gx.falseFn};
   GXValidFnc[28]={ id:28 ,lvl:2,type:"int",len:12,dec:0,sign:false,pic:"ZZZZZZZZZZZ9",ro:0,isacc:0,grid:25,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vID",fmt:0,gxz:"ZV16Id",gxold:"OV16Id",gxvar:"AV16Id",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',v2v:function(Value){if(Value!==undefined)gx.O.AV16Id=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV16Id=gx.num.intval(Value)},v2c:function(row){gx.fn.setGridControlValue("vID",row || gx.fn.currentGridRowImpl(25),gx.O.AV16Id,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV16Id=gx.num.intval(this.val(row))},val:function(row){return gx.fn.getGridIntegerValue("vID",row || gx.fn.currentGridRowImpl(25),gx.thousandSeparator)},nac:gx.falseFn};
   GXValidFnc[29]={ id: 29, fld:"",grid:0};
   GXValidFnc[30]={ id: 30, fld:"",grid:0};
   GXValidFnc[31]={ id: 31, fld:"GAM_PAGINGWW",grid:0};
   GXValidFnc[32]={ id: 32, fld:"",grid:0};
   GXValidFnc[33]={ id: 33, fld:"",grid:0};
   GXValidFnc[34]={ id: 34, fld:"GAM_PAGINGWW_TBLPAGINGBUTTONS",grid:0};
   GXValidFnc[37]={ id: 37, fld:"GAM_PAGINGWW_BTNFIRST",grid:0,evt:"e182f1_client"};
   GXValidFnc[39]={ id: 39, fld:"GAM_PAGINGWW_BTNPREVIOUS",grid:0,evt:"e192f1_client"};
   GXValidFnc[41]={ id: 41, fld:"GAM_PAGINGWW_BTNNEXT",grid:0,evt:"e202f1_client"};
   GXValidFnc[42]={ id: 42, fld:"",grid:0};
   GXValidFnc[43]={ id: 43, fld:"",grid:0};
   GXValidFnc[44]={ id: 44, fld:"",grid:0};
   GXValidFnc[45]={ id:45 ,lvl:0,type:"int",len:4,dec:0,sign:false,pic:"ZZZ9",ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCURRENTPAGE",fmt:0,gxz:"ZV7CurrentPage",gxold:"OV7CurrentPage",gxvar:"AV7CurrentPage",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV7CurrentPage=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV7CurrentPage=gx.num.intval(Value)},v2c:function(){gx.fn.setControlValue("vCURRENTPAGE",gx.O.AV7CurrentPage,0)},c2v:function(){if(this.val()!==undefined)gx.O.AV7CurrentPage=gx.num.intval(this.val())},val:function(){return gx.fn.getIntegerValue("vCURRENTPAGE",gx.thousandSeparator)},nac:gx.falseFn};
   GXValidFnc[46]={ id: 46, fld:"GAM_FILTERSWW",grid:0};
   GXValidFnc[47]={ id: 47, fld:"",grid:0};
   GXValidFnc[48]={ id: 48, fld:"",grid:0};
   GXValidFnc[49]={ id: 49, fld:"GAM_FILTERSWW_HIDEFILTERS",grid:0,evt:"e112f1_client"};
   GXValidFnc[50]={ id: 50, fld:"",grid:0};
   GXValidFnc[51]={ id: 51, fld:"",grid:0};
   GXValidFnc[52]={ id: 52, fld:"GAM_FILTERSWW_TABLEFILTERS",grid:0};
   GXValidFnc[53]={ id: 53, fld:"",grid:0};
   GXValidFnc[54]={ id: 54, fld:"",grid:0};
   GXValidFnc[55]={ id: 55, fld:"",grid:0};
   GXValidFnc[56]={ id: 56, fld:"",grid:0};
   GXValidFnc[57]={ id:57 ,lvl:0,type:"char",len:40,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vFILROLEGUID",fmt:0,gxz:"ZV30FilRoleGUID",gxold:"OV30FilRoleGUID",gxvar:"AV30FilRoleGUID",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV30FilRoleGUID=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV30FilRoleGUID=Value},v2c:function(){gx.fn.setControlValue("vFILROLEGUID",gx.O.AV30FilRoleGUID,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV30FilRoleGUID=this.val()},val:function(){return gx.fn.getControlValue("vFILROLEGUID")},nac:gx.falseFn};
   this.declareDomainHdlr( 57 , function() {
   });
   GXValidFnc[58]={ id: 58, fld:"",grid:0};
   GXValidFnc[59]={ id: 59, fld:"",grid:0};
   GXValidFnc[60]={ id: 60, fld:"",grid:0};
   GXValidFnc[61]={ id: 61, fld:"",grid:0};
   GXValidFnc[62]={ id:62 ,lvl:0,type:"char",len:254,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vFILEXTERNALID",fmt:0,gxz:"ZV11FilExternalId",gxold:"OV11FilExternalId",gxvar:"AV11FilExternalId",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV11FilExternalId=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV11FilExternalId=Value},v2c:function(){gx.fn.setControlValue("vFILEXTERNALID",gx.O.AV11FilExternalId,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV11FilExternalId=this.val()},val:function(){return gx.fn.getControlValue("vFILEXTERNALID")},nac:gx.falseFn};
   this.declareDomainHdlr( 62 , function() {
   });
   GXValidFnc[63]={ id: 63, fld:"",grid:0};
   GXValidFnc[64]={ id: 64, fld:"",grid:0};
   GXValidFnc[65]={ id: 65, fld:"GAM_FILTERSWW_CLEARFILTERS",grid:0,evt:"e122f1_client"};
   GXValidFnc[66]={ id: 66, fld:"",grid:0};
   GXValidFnc[67]={ id: 67, fld:"GAM_FILTERSWW_APPLY",grid:0,evt:"e132f1_client"};
   GXValidFnc[68]={ id: 68, fld:"",grid:0};
   GXValidFnc[69]={ id: 69, fld:"",grid:0};
   GXValidFnc[71]={ id: 71, fld:"",grid:0};
   GXValidFnc[72]={ id: 72, fld:"",grid:0};
   GXValidFnc[73]={ id: 73, fld:"GAM_FOOTERPOPUP",grid:0};
   GXValidFnc[74]={ id: 74, fld:"",grid:0};
   GXValidFnc[75]={ id: 75, fld:"",grid:0};
   GXValidFnc[76]={ id: 76, fld:"GAM_FOOTERPOPUP_TABLEBUTTONS",grid:0};
   GXValidFnc[77]={ id: 77, fld:"",grid:0};
   GXValidFnc[78]={ id: 78, fld:"GAM_FOOTERPOPUP_BTNCANCEL",grid:0,evt:"e152f2_client"};
   GXValidFnc[79]={ id: 79, fld:"",grid:0};
   GXValidFnc[80]={ id: 80, fld:"GAM_FOOTERPOPUP_BTNCONFIRM",grid:0,evt:"e142f2_client"};
   this.AV28Search = "" ;
   this.ZV28Search = "" ;
   this.OV28Search = "" ;
   this.ZV22Select = false ;
   this.OV22Select = false ;
   this.ZV18Name = "" ;
   this.OV18Name = "" ;
   this.ZV16Id = 0 ;
   this.OV16Id = 0 ;
   this.AV7CurrentPage = 0 ;
   this.ZV7CurrentPage = 0 ;
   this.OV7CurrentPage = 0 ;
   this.AV30FilRoleGUID = "" ;
   this.ZV30FilRoleGUID = "" ;
   this.OV30FilRoleGUID = "" ;
   this.AV11FilExternalId = "" ;
   this.ZV11FilExternalId = "" ;
   this.OV11FilExternalId = "" ;
   this.AV28Search = "" ;
   this.AV7CurrentPage = 0 ;
   this.AV30FilRoleGUID = "" ;
   this.AV11FilExternalId = "" ;
   this.AV29UserGUID = "" ;
   this.AV22Select = false ;
   this.AV18Name = "" ;
   this.AV16Id = 0 ;
   this.AV17isOK = false ;
   this.Events = {"e142f2_client": ["'CONFIRM'", true] ,"e152f2_client": ["'CANCEL'", true] ,"e212f2_client": ["ENTER", true] ,"e222f2_client": ["CANCEL", true] ,"e132f1_client": ["'APPLY'", false] ,"e122f1_client": ["'CLEARFILTERS'", false] ,"e112f1_client": ["'HIDE'", false] ,"e182f1_client": ["'FIRST'", false] ,"e192f1_client": ["'PREVIOUS'", false] ,"e202f1_client": ["'NEXT'", false]};
   this.EvtParms["REFRESH"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{av:'AV28Search',fld:'vSEARCH',pic:''},{av:'AV11FilExternalId',fld:'vFILEXTERNALID',pic:''},{av:'AV30FilRoleGUID',fld:'vFILROLEGUID',pic:''},{av:'AV7CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'},{av:'AV29UserGUID',fld:'vUSERGUID',pic:'',hsh:true}],[]];
   this.EvtParms["GRIDWW.LOAD"] = [[{av:'AV29UserGUID',fld:'vUSERGUID',pic:'',hsh:true},{av:'AV28Search',fld:'vSEARCH',pic:''},{av:'AV11FilExternalId',fld:'vFILEXTERNALID',pic:''},{av:'AV30FilRoleGUID',fld:'vFILROLEGUID',pic:''},{av:'AV7CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'}],[{av:'AV22Select',fld:'vSELECT',pic:''},{av:'AV16Id',fld:'vID',pic:'ZZZZZZZZZZZ9',hsh:true},{av:'AV18Name',fld:'vNAME',pic:''},{ctrl:'GAM_PAGINGWW_BTNNEXT',prop:'Enabled'},{ctrl:'GAM_PAGINGWW_BTNFIRST',prop:'Enabled'},{ctrl:'GAM_PAGINGWW_BTNPREVIOUS',prop:'Enabled'}]];
   this.EvtParms["'CONFIRM'"] = [[{av:'AV29UserGUID',fld:'vUSERGUID',pic:'',hsh:true},{av:'AV22Select',fld:'vSELECT',grid:25,pic:''},{av:'GRIDWW_nFirstRecordOnPage'},{av:'nRC_GXsfl_25',ctrl:'GRIDWW',grid:25,prop:'GridRC',grid:25},{av:'AV16Id',fld:'vID',grid:25,pic:'ZZZZZZZZZZZ9',hsh:true},{av:'AV17isOK',fld:'vISOK',pic:''}],[{av:'AV17isOK',fld:'vISOK',pic:''},{ctrl:'WCMESSAGES'}]];
   this.EvtParms["'CANCEL'"] = [[{av:'AV29UserGUID',fld:'vUSERGUID',pic:'',hsh:true}],[]];
   this.EvtParms["'APPLY'"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{av:'AV29UserGUID',fld:'vUSERGUID',pic:'',hsh:true},{av:'AV28Search',fld:'vSEARCH',pic:''},{av:'AV11FilExternalId',fld:'vFILEXTERNALID',pic:''},{av:'AV30FilRoleGUID',fld:'vFILROLEGUID',pic:''},{av:'AV7CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'}],[]];
   this.EvtParms["'CLEARFILTERS'"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{av:'AV29UserGUID',fld:'vUSERGUID',pic:'',hsh:true},{av:'AV28Search',fld:'vSEARCH',pic:''},{av:'AV11FilExternalId',fld:'vFILEXTERNALID',pic:''},{av:'AV30FilRoleGUID',fld:'vFILROLEGUID',pic:''},{av:'AV7CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'}],[{av:'AV30FilRoleGUID',fld:'vFILROLEGUID',pic:''},{av:'AV11FilExternalId',fld:'vFILEXTERNALID',pic:''}]];
   this.EvtParms["'HIDE'"] = [[{av:'gx.fn.getCtrlProperty("GAM_FILTERSWW","Class")',ctrl:'GAM_FILTERSWW',prop:'Class'}],[{av:'gx.fn.getCtrlProperty("GAM_FILTERSWW","Class")',ctrl:'GAM_FILTERSWW',prop:'Class'},{av:'gx.fn.getCtrlProperty("GAM_HEADERWW_TOGGLEFILTERS","Tooltiptext")',ctrl:'GAM_HEADERWW_TOGGLEFILTERS',prop:'Tooltiptext'}]];
   this.EvtParms["'FIRST'"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{av:'AV29UserGUID',fld:'vUSERGUID',pic:'',hsh:true},{av:'AV28Search',fld:'vSEARCH',pic:''},{av:'AV11FilExternalId',fld:'vFILEXTERNALID',pic:''},{av:'AV30FilRoleGUID',fld:'vFILROLEGUID',pic:''},{av:'AV7CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'}],[{av:'AV7CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'}]];
   this.EvtParms["'PREVIOUS'"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{av:'AV29UserGUID',fld:'vUSERGUID',pic:'',hsh:true},{av:'AV28Search',fld:'vSEARCH',pic:''},{av:'AV11FilExternalId',fld:'vFILEXTERNALID',pic:''},{av:'AV30FilRoleGUID',fld:'vFILROLEGUID',pic:''},{av:'AV7CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'}],[{av:'AV7CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'}]];
   this.EvtParms["'NEXT'"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{av:'AV29UserGUID',fld:'vUSERGUID',pic:'',hsh:true},{av:'AV28Search',fld:'vSEARCH',pic:''},{av:'AV11FilExternalId',fld:'vFILEXTERNALID',pic:''},{av:'AV30FilRoleGUID',fld:'vFILROLEGUID',pic:''},{av:'AV7CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'}],[{av:'AV7CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'}]];
   this.EvtParms["ENTER"] = [[],[]];
   this.setVCMap("AV29UserGUID", "vUSERGUID", 0, "char", 40, 0);
   this.setVCMap("AV17isOK", "vISOK", 0, "boolean", 4, 0);
   this.setVCMap("AV29UserGUID", "vUSERGUID", 0, "char", 40, 0);
   this.setVCMap("AV29UserGUID", "vUSERGUID", 0, "char", 40, 0);
   GridwwContainer.addRefreshingVar({rfrVar:"AV29UserGUID"});
   GridwwContainer.addRefreshingVar(this.GXValidFnc[16]);
   GridwwContainer.addRefreshingVar(this.GXValidFnc[62]);
   GridwwContainer.addRefreshingVar(this.GXValidFnc[57]);
   GridwwContainer.addRefreshingVar(this.GXValidFnc[45]);
   GridwwContainer.addRefreshingParm({rfrVar:"AV29UserGUID"});
   GridwwContainer.addRefreshingParm(this.GXValidFnc[16]);
   GridwwContainer.addRefreshingParm(this.GXValidFnc[62]);
   GridwwContainer.addRefreshingParm(this.GXValidFnc[57]);
   GridwwContainer.addRefreshingParm(this.GXValidFnc[45]);
   this.Initialize( );
   this.setComponent({id: "WCMESSAGES" ,GXClass: null , Prefix: "W0070" , lvl: 1 });
});
gx.wi( function() { gx.createParentObj(this.gam_userroleselect);});
